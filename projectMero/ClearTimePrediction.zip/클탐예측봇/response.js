function response(room, msg, sender, isGroupChat, replier, imageDB, packageName, isMultiChat) {
    if ((room == "자괴감" || isGroupChat == false) && msg[0] == "/") {
        var fileName = "spec.json";
        if (Database.exists(fileName)) {
            var spec = Database.readObject(fileName);
            if(msg == "/예측"){
                var list = [];
                for (var i = 0; i < spec.member.length - 1; ++i) {
                    if (spec.member[i].isPlaying) {
                        list.push(spec.member[i]);
                    }
                }

                //보스 이름 받는다
                var bossIndex = -1;
                if(msg.split(" ").length == 3){
                    var bossName = msg.split(" ")[1];
                    for(var i=0; i<list.length; ++i){
                        if(list[i].job != "이위로"){
                            continue;
                        }
                        if(list[i].name == bossName){
                            bossIndex = i;
                            break;
                        }
                    }
                    if(bossIndex == -1){
                        replier.reply("보스 이름을 찾을 수 없습니다.");
                        return;
                    }
                }
                else{
                    var errorReply = "입력 오류.\n[예측][][보스이름][][파티 멤버 이름(,)]\n로 적어주세요.";
                    replier.reply(errorReply);
                    return;
                }
                var reply = "예상 ";
                reply += list[bossIndex].name;
                reply += " 클리어 시간은\n";
                //파티 전투력 받는다
                var partyMemberList = [];
                var partyCombatStatus = 0;
                if(msg.split(" ")[2].indexof(",") == -1){//파티 멤버 한 명
                    for(var i = 0; i<list.length;++i){
                        if(msg.split(" ")[2] == list[i].name){
                            partyMemberList.push(list[i]);
                            partyCombatStatus += list[i].stat;
                            break;
                        }
                    }
                    if(partyCombatStatus == 0){
                        replier.reply("파티 멤버를 찾을 수 없습니다.");
                        return;
                    }
                }
                else{//파티 멤버 다수
                    for(var partyMemberNumber =0; partyMemberNumber<msg.split(" ")[2].split(",").length;++partyMemberNumber){
                        var previousPartyCombatStatus = partyCombatStatus;
                        for(var i=0; i<list.length;++i){
                            if(msg.split(" ")[2].split(",")[partyMemberNumber] == list[i].name){
                                partyMemberList.push(list[i]);
                                partyCombatStatus += list[i].stat;
                                break;
                            }
                        }
                        if(previousPartyCombatStatus == partyCombatStatus){
                            var memberFindError = "파티 멤버를 찾을 수 없습니다. 오류 파티원 이름:\n";
                            memberFindError += msg.split(" ")[2].split(",")[partyMemberNumber];
                            return;
                        }
                    }
                }
                //예상시간 산출
                if(partyCombatStatus < list[bossIndex].stat){
                    replier.reply("깰 수 없습니다.");
                    return;
                }
                var magnification = 0.0;
                magnification = partyCombatStatus / list[bossIndex].stat;
                var clearSec = 0;
                clearSec = 1800 / magnification;                
                //예상시간 출력
                reply += (clearSec / 60) + "분 " + (clearSec % 60) + "초 입니다";
                replier.reply(reply);
            }
        }
    }
}